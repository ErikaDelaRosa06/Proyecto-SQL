SELECT EXTRACT(MONTH FROM rental_date) AS mes,
COUNT(*) AS total_alquileres
FROM rental
GROUP BY mes
ORDER BY mes;