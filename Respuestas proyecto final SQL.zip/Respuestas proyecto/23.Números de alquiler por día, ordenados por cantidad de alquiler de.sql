SELECT DATE(rental_date) AS dia, COUNT(*) AS numero_alquileres
FROM rental
GROUP BY dia
ORDER BY numero_alquileres DESC;