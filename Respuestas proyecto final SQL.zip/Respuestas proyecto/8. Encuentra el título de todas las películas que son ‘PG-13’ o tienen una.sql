SELECT "title", "rating","length"
FROM "film"
WHERE "rating" = 'PG-13'
   OR "length" > 180;