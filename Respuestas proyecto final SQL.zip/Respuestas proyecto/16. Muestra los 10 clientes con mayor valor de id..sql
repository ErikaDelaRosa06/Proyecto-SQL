SELECT "first_name", "last_name", "customer_id"
FROM "customer"
ORDER BY "customer_id" DESC
LIMIT 10;