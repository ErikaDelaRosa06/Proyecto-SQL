--Contar por nombre
SELECT "first_name", COUNT(*) AS total
FROM "actor"
GROUP BY "first_name"
ORDER BY "total" DESC;

--Nombre más repetido
SELECT "first_name", COUNT(*) AS total
FROM "actor"
GROUP BY "first_name"
ORDER BY "total" desc;

