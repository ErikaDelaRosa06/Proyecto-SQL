select "first_name", "last_name", "actor_id"
from actor
where "actor_id" between '30' and '40';

