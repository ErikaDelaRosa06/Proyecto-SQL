CREATE TEMP TABLE peliculas_alquiladas AS
SELECT f.title, COUNT(*) AS total
FROM film f
JOIN inventory i ON f.film_id = i.film_id
JOIN rental r ON i.inventory_id = r.inventory_id
GROUP BY f.title
HAVING COUNT(*) >= 10;