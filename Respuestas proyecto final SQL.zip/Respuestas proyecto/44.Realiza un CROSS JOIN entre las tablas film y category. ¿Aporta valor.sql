SELECT f.title, c.name
FROM film f
CROSS JOIN category c;