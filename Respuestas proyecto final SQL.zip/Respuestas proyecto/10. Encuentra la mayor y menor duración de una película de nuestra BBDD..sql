SELECT MAX("length") AS "duracion_maxima", MIN("length") AS "duracion_minima"
FROM film;