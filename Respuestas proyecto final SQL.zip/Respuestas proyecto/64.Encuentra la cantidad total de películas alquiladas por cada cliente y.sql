SELECT c.customer_id, c.first_name, c.last_name, COUNT(*) AS total_alquileres
FROM customer c
JOIN rental r ON c.customer_id = r.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name;