SELECT actor_id, COUNT(film_id) AS numero_peliculas
FROM film_actor
GROUP BY actor_id
HAVING COUNT(film_id) > 40;