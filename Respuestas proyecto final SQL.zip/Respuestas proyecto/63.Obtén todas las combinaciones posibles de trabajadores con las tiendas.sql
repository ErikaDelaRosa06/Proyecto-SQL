SELECT s.first_name, s.last_name, st.store_id
FROM staff s
CROSS JOIN store st;