SELECT MIN(actor_id) AS id_minimo,
MAX(actor_id) AS id_maximo
FROM actor;