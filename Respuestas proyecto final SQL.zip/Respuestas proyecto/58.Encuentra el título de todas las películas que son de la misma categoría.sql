SELECT f.title
FROM film f
JOIN film_category fc ON f.film_id = fc.film_id
WHERE fc.category_id = (
    SELECT fc2.category_id
    FROM film f2
    JOIN film_category fc2 ON f2.film_id = fc2.film_id
    WHERE f2.title = 'ANIMATION'
    LIMIT 1
);