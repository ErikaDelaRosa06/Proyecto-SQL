select "first_name", "last_name"
from actor a
where "last_name" = 'ALLEN';
