SELECT VARIANCE("replacement_cost") AS "variabilidad_replacement_cost"
FROM "film";