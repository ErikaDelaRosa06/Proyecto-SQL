SELECT "title", "rating"
FROM film
WHERE rating NOT IN ('NC-17', 'G');
