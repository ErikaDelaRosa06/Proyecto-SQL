SELECT "amount", "payment_date"
FROM "payment"
ORDER BY "payment_date" desc
	limit 3;

	