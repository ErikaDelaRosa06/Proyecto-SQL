select "title", "length"
from "film"
order by "length" asc;