SELECT customer_id, COUNT(*) AS total_alquileres
FROM rental
GROUP BY customer_id;