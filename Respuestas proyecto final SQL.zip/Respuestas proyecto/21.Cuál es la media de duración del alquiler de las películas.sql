SELECT AVG(rental_duration) AS media_duracion_alquiler
FROM film;